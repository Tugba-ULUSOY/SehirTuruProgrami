
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Scanner;

/**
 *
 * @author tugba
 */
public class Main 
{
    public static void islemleri_bastir()
    {
        System.out.println("0 - İşlemleri Görüntüle");
        System.out.println("1 - Bir sonraki şehire git.");
        System.out.println("2 - Bir önceki şehire git.");
        System.out.println("3 - Uygulamadan Çık.");
    }
    
    public static void sehirleri_turla(LinkedList<String> sehirler)
    {
        ListIterator<String> iterator = sehirler.listIterator();
        
        int islem;
        
        islemleri_bastir();
        
        Scanner scanner = new Scanner(System.in);
        
        
        if(!iterator.hasNext()) // LinkedList imiz boşsa karşımıza true olarak çıkıcak.
        {
            System.out.println("Herhangi bir şehir bulunmuyor.");
        }
        
        boolean cikis = false;
        boolean ileri = true;
        
        while(!cikis)
        {
            System.out.println("Bir işlem seçiniz: ");
            
            islem = scanner.nextInt();
            
            switch(islem) // Her case bitiminde break; konulmak zorundadır.
            {
                case 0:
                    islemleri_bastir();
                    break;
                case 1: 
                    // Bu if iterator un gösterdiği referanstan kaynaklı hatayı önlemek için
                    if(!ileri)  // Önceki turda geri gidilmişse
                    {
                        if(iterator.hasNext())
                        {
                            iterator.next();
                        }
                        ileri = true; //Bu turda ileri gidiliyor.
                    }
                    if(iterator.hasNext()) // Kendinden sonra bir obje var mı
                    {
                        System.out.println("Şehre gidiliyor: " + iterator.next());
                    }
                    else // gösterilecek obje kalmadıysa
                    {
                        System.out.println("Gidilecek Şehir Kalmadı...");
                        ileri = true;
                    }
                    break;
                case 2: 
                    // Bu if iterator un gösterdiği referanstan kaynaklı hatayı önlemek için
                    if(ileri) // Önceki turda ileri gidilmişse
                    {
                        if(iterator.hasPrevious())
                        {
                            iterator.previous();
                        }
                        ileri = false; // Geri gidiliyor.
                    }
                    if(iterator.hasPrevious()) // Kendinden önce bir obje var mı
                    {
                        System.out.println("Şehre gidiliyor: " + iterator.previous());
                    }
                    else
                    {
                        System.out.println("Şehir Turu Başladı...");
                    }
                    break;
                case 3:
                    cikis = true;
                    System.out.println("Uygulamadan çıkılıyor... ");
                    break;
            
            }
            
        }
        
    }
    public static void main(String[] args) 
    {
        LinkedList<String> sehirler = new LinkedList<String>();
        
        sehirler.add("Ankara");
        sehirler.add("Eskişehir");
        sehirler.add("Afyon");
        sehirler.add("Antalya");
        sehirler.add("Denizli");
        sehirler.add("Malatya");
        sehirler.add("İstanbul");
        sehirler.add("Zonguldak");
        sehirler.add("İzmir");
        sehirler.add("Konya");
        sehirler.add("Kastamonu");
        sehirler.add("Kocaeli");
        sehirler.add("Bursa");
        
        sehirleri_turla(sehirler);
    }
    
}
